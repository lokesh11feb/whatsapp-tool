<?php

return [

    'name'              => 'Flowmaker',
    'description'       => 'This is my awesome module',

];