<?php

return
[
    'version' => '3.7.0'
];
