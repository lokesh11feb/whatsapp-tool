<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Cost extends Model
{

    protected $modelName = "App\Models\Cost";

    protected $table = 'action_credit_cost';

    protected $guarded = [];
}
