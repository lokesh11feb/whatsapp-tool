<?php

return [
    'name' => 'Dashboard'
];
