<?php


namespace Modules\StripehSubscribe\Http\Controllers;


class App
{
    public function validate($user)
    {
    }
}