<?php

return [

    'name'              => 'Agents',
    'description'       => 'This is my awesome module',

];