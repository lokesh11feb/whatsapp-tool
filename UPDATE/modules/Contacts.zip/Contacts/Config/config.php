<?php

return [
    'name' => 'Contacts'
];
